### 前言
- demo为国银在线网银支付php版本demo

### demo
- HttpClient.php  	http通信类,包含post数据的方法
- Util.php		   	工具类，包含生成数字签名，验证数字签名，查看调试信息，数据记录等工具
- test.php			具体演示程序

### 更新
- 20170429
