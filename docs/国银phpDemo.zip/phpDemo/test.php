<?php
/*
 *      demo
 * 
 */
require_once('util.php');
require_once('HttpCilent.php');

class test{
    private $applyUrl;
    private $queryUrl;
    private $gymchtId;
    private $gymchtKey;
    private $HttpClient;
    private $Util;
            
    function _initialize()
    {
            $this->applyUrl = "http://112.74.25.79:9999/gyprovider/netpay/applyPay.do";//网银支付申请接口
            $this->queryUrl = "http://112.74.25.79:9999/gyprovider/netpay/queryPay.do";//网银支付查询接口
            $this->gymchtId = "##########";//国银分配的商户号,正式的交易的时候换成正式商户号
            $this->gymchtKey = "###############################"; //国银分配的商户密钥,正式的交易的时候换成正式商户密钥
            $this->HttpClient = new HttpClient();
            $this->Util = new Util();
    }
    
    
    /**
     *      请求支付
     *      @params         string              $sn                 商户订单号 
     *      @params         int                 $money              订单金额,单位为分,只允许数字
     *      @params         string              $bankSegment        银行代号
     * 
     */
    public function applyPay($sn, $money, $bankSegment)
    {
            $data = array();
            $data['gymchtId'] = $this->gymchtId;//商户号
            $data['tradeSn'] = $sn;//商户订单号
            $data['orderAmount'] = $money;//订单金额
            $data['bankSegment'] = $bankSegment;//银行代号
            $data['cardType'] = '00';//00-贷记 01-借记 02-准贷记
            $server = $this->_server();
            $host = $server['HTTP_HOST'];
            $data['notifyUrl'] = "http://".$host."/#######/notice_result";//回调通知地址
            $data['callbackUrl'] = "http://www.guoyinpay.com/";//回调跳转地址
            $data['goodsName'] = "guoyin";//商品名称
            $data['channelType'] = "2";//1-pc 2-手机
            $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串
            $sign = $this->Util->createSign($data);//数字签名
            $data['sign'] = $sign;

            $rs = $this->HttpClient->httpClient($data, $this->applyUrl);
            $rs = json_decode($rs, true);

            $array = array();

            if($rs['resultCode'] == '00000'){
                $sign = $rs['sign'];
                unset($rs['sign']);
                ksort($rs);
                
                
                if($this->Util->isGySign($rs, $this->gymchtKey,$sign)){
                    $array['payUrl'] = $rs['payUrl'];
                }
            }


            return $array;
    }
    
    /*
     *      回调通知地址
     * 
     */
    public function notice_result()
    {
            $rs = file_get_contents("php://input");
            $rs = json_decode($rs, true);
            if($this->Util->isGySign($rs, $this->gymchtKey,$rs['sign']))
            {
                    if($rs['tradeState'] == 'SUCCESS'){

                        //更改订单状态;notify_url 有可能重复通知,商户系统需要做去重处理,避免多次发货

                        echo "success";
                        exit();
                    }else{
                        echo "failure";
                        exit();
                    }
                
            }else{
                    echo "failure";
            }
            
    }
    
    /*
     *      交易查询接口
     *      
     */
    public function verify_result()
    {
            $data = array();
            $data['gymchtId'] = $this->gymchtId;//商户号
            $data['tradeSn'] = $sn;//商户订单号
            $data['orderAmount'] = $money;//订单金额
            $data['nonce'] = md5(time().mt_rand(0,1000));//随机字符串
            $sign = $this->createSign($data);//数字签名
            $data['sign'] = $sign;
        
            $rs = $this->HttpClient->httpClient($data, $this->queryUrl);
            $rs = json_decode($rs, true);
            
            if(($rs['resultCode'] == '00000') && ($rs['tradeState']=='SUCCESS'))
            {
                    if($this->isGySign($rs, $this->gymchtKey,$rs['sign']))
                    {
                            //查询成功业务逻辑
                    }
            }
            
    }

    
}