<?php

/**
 *      工具类
 *      
 *      
 */

class Util {
    
    public $debugInfo;

    /**
    *       创建md5摘要,规则是:按参数名称a-z排序,遇到空值的参数不参加签名。
    *       @params         array               $data               参与签名的数组
    *       @params         string              $gymchtKey          商户密钥
    *       @return         string              $sign               返回生成的sign
    */
    public function createSign($data,$gymchtKey) 
    {
            $signPars = "";

            ksort($data);

            foreach($data as $k => $v) {
                    if("" != $v && "sign" != $k) {
                            $signPars .= $k . "=" . $v . "&";
                    }
            }

            $signPars .= "key=" . $gymchtKey;

            $sign = strtoupper(md5($signPars));

            return $sign;
    }
    
    /*
     *      验证是否国银签名
     *      @params         array               $data               参与签名的数组
     *      @params         string              $gymchtKey          商户密钥
     *      @return         bool                                    true:是 false:否
     */
    public function isGySign($data,$gymchtKey,$sign)
    {
            $gySign = $this->createSign($data,$gymchtKey);
            
            return $sign==$gySign;
    }
    
    /*
     *      设置调试内容
     *      @params         string               $debugInfo          调试内容 
     * 
     */
    public function setDebugInfo($debugInfo)
    {
            $this->debugInfo = $debugInfo;
    }
    
    /*
     *      获取调试内容
     * 
     * 
     */
    public function getDebugInfo()
    {
            return $this->debugInfo;
    }
    
    /*
     *      数据记录
     * 
     * 
     */
    public static function dataRecodes($title,$data)
    {
            $handler = fopen('result.txt','a+');
            $content = "================".$title."===================\n";
            if(is_string($data) === true){
                $content .= $data."\n";
            }
            if(is_array($data) === true){
                forEach($data as $k=>$v){
                    $content .= "key: ".$k." value: ".$v."\n";
                }
            }
            $flag = fwrite($handler,$content);
            fclose($handler);
            return $flag;
    }
    
    
    
}