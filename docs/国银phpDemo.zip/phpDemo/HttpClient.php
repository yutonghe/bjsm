<?php

/**
 * 
 *      http通信类
 *      
 * 
 */

class HttpClient {
    
    /*
     *      post方法请求
     *      @param      array       $data       post数据       
     *      @param      string      $url        server url
     *      @return     json        $rs         接口返回数据,此demo中为返回json数据
     */
    public static function httpClient($data, $url) 
    {
            $postdata = http_build_query($data);
            try {
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_URL, $Url);
                curl_setopt($ch, CURLOPT_HEADER, 0);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
                curl_setopt($ch, CURLOPT_POST, 1);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postdata);
                $res = curl_exec($ch);
                curl_close($ch);
                return $res;
            } catch (Exception $e) {
                $errorMsg = $e->getMessage();
                return false;
            }
    }
    
    
}